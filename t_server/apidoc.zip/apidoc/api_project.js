define({
  "name": "",
  "version": "0.0.0",
  "description": "",
  "sampleUrl": false,
  "apidoc": "0.2.0",
  "generator": {
    "name": "apidoc",
    "time": "2016-12-06T01:55:41.379Z",
    "url": "http://apidocjs.com",
    "version": "0.16.1"
  }
});
